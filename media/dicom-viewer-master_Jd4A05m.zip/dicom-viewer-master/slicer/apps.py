from django.apps import AppConfig


class SlicerConfig(AppConfig):
    name = 'slicer'
